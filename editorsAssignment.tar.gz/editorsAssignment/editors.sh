#!/bin/bash
# Editors

source /scripts/functions.sh

# Gather Student Work

clear
is_super_user
student_info Editors

# Question 1

check_existence 1 /home/linuxuser/viFile.txt f
cat /home/linuxuser/viFile.txt | tee -a $outfile
blank_line

# Question 2

echo 'Question 2:'
echo 'Found kindergarten:' $(grep -i kindergarten /home/linuxuser/files/kindergarten | wc -l) times | tee -a $outfile
check_existence 2 /home/linuxuser/files/cambrian.txt f
echo 'Found Cambrian:' $(grep -i Cambrian /home/linuxuser/files/cambrian.txt | wc -l) times | tee -a $outfile
blank_line

# Question 3

echo 'Question 3:'
echo 'Number of green eggs:' $(grep -i green /home/linuxuser/files/greeneggsandham | wc -l) | tee -a $outfile
echo 'Number of yellow eggs:' $(grep -i yellow /home/linuxuser/files/greeneggsandham | wc -l) | tee -a $outfile
echo 'Sam still exists:' $(grep Sam /home/linuxuser/files/greeneggsandham | wc -l) | tee -a $outfile
echo 'Pam-I-Am:' $(grep Pam /home/linuxuser/files/greeneggsandham | wc -l) | tee -a $outfile
blank_line

# Question 4

check_existence 4 /home/linuxuser/files/script.sed f
tail /home/linuxuser/files/script.sed | tee -a $outfile
blank_line
check_existence 4 /home/linuxuser/files/phone f
tail /home/linuxuser/files/phone | tee -a $outfile
blank_line

mail_out Editors
